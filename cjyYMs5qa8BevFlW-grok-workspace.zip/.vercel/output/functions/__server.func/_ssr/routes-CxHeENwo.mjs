import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LifeBuoy, i as MonitorPlay, o as Box, r as Sun, s as AudioLines, t as Users } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CxHeENwo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FlexCarousel({ items, preset = "liquid", intro = "none", cardHeight = .62, gap = 12, squeeze = .2, focusOnClick = false, captions = false }) {
	const rootRef = (0, import_react.useRef)(null);
	const cardRefs = (0, import_react.useRef)([]);
	const focus = (0, import_react.useRef)(0);
	const target = (0, import_react.useRef)(0);
	const wakeRef = (0, import_react.useRef)(() => {});
	const drag = (0, import_react.useRef)({
		active: false,
		moved: false,
		originX: 0,
		originFocus: 0,
		step: 240
	});
	(0, import_react.useEffect)(() => {
		const root = rootRef.current;
		if (!root) return;
		let frame = 0;
		let running = true;
		const introStart = performance.now();
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const metrics = () => {
			const rect = root.getBoundingClientRect();
			const cardH = Math.max(180, rect.height * cardHeight);
			const cardW = Math.min(rect.width * .78, cardH * 1.45);
			return {
				rect,
				cardH,
				cardW,
				step: cardW * (1 - squeeze * .85) + gap
			};
		};
		const layout = () => {
			const { rect, cardH, cardW, step } = metrics();
			drag.current.step = step;
			const elapsed = (performance.now() - introStart) / 1e3;
			const ease = 1 - (1 - (intro === "rise" && !reduce ? Math.min(1, elapsed / .9) : 1)) ** 3;
			items.forEach((_, i) => {
				const el = cardRefs.current[i];
				if (!el) return;
				const offset = i - focus.current;
				const abs = Math.abs(offset);
				const scale = Math.max(.74, 1 - Math.min(abs, 1.6) * squeeze);
				const rot = preset === "liquid" ? offset * -7 : 0;
				const x = rect.width / 2 + offset * step - cardW / 2;
				const y = (rect.height - cardH) / 2 + (1 - ease) * (26 + i * 5);
				el.style.width = `${cardW}px`;
				el.style.height = `${cardH}px`;
				el.style.opacity = String((abs > 2.45 ? 0 : 1) * ease);
				el.style.zIndex = String(30 - Math.round(abs * 3));
				el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale}) rotate(${rot}deg)`;
			});
		};
		const tick = () => {
			if (!running) return;
			if (!drag.current.active) {
				focus.current += (target.current - focus.current) * (reduce ? 1 : .14);
				if (Math.abs(target.current - focus.current) < .001) focus.current = target.current;
			}
			layout();
			const introLive = intro === "rise" && !reduce && performance.now() - introStart < 1100;
			frame = Math.abs(target.current - focus.current) > .001 || drag.current.active || introLive ? requestAnimationFrame(tick) : 0;
		};
		const wake = () => {
			if (!frame) frame = requestAnimationFrame(tick);
		};
		wakeRef.current = wake;
		wake();
		const clampIndex = (value) => Math.max(0, Math.min(items.length - 1, value));
		const onPointerDown = (event) => {
			if (event.pointerType === "mouse" && event.button !== 0) return;
			const { step } = metrics();
			drag.current.active = true;
			drag.current.moved = false;
			drag.current.originX = event.clientX;
			drag.current.originFocus = focus.current;
			drag.current.step = step;
			root.setPointerCapture(event.pointerId);
		};
		const onPointerMove = (event) => {
			if (!drag.current.active) return;
			const dx = event.clientX - drag.current.originX;
			if (Math.abs(dx) > 8) drag.current.moved = true;
			const next = clampIndex(drag.current.originFocus - dx / drag.current.step);
			focus.current = next;
			target.current = next;
			wake();
		};
		const onPointerUp = (event) => {
			if (!drag.current.active) return;
			drag.current.active = false;
			if (root.hasPointerCapture(event.pointerId)) root.releasePointerCapture(event.pointerId);
			target.current = clampIndex(Math.round(focus.current));
			wake();
		};
		const onClick = (event) => {
			const moved = drag.current.moved;
			drag.current.moved = false;
			if (!focusOnClick || moved) return;
			const button = event.target?.closest("button[data-index]");
			if (!button) return;
			const index = Number(button.getAttribute("data-index"));
			if (!Number.isFinite(index)) return;
			target.current = index;
			wake();
		};
		const onKey = (event) => {
			if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
			event.preventDefault();
			target.current = clampIndex(Math.round(target.current) + (event.key === "ArrowRight" ? 1 : -1));
			wake();
		};
		root.addEventListener("pointerdown", onPointerDown);
		root.addEventListener("pointermove", onPointerMove);
		root.addEventListener("pointerup", onPointerUp);
		root.addEventListener("pointercancel", onPointerUp);
		root.addEventListener("click", onClick);
		root.addEventListener("keydown", onKey);
		window.addEventListener("resize", wake);
		return () => {
			running = false;
			if (frame) cancelAnimationFrame(frame);
			root.removeEventListener("pointerdown", onPointerDown);
			root.removeEventListener("pointermove", onPointerMove);
			root.removeEventListener("pointerup", onPointerUp);
			root.removeEventListener("pointercancel", onPointerUp);
			root.removeEventListener("click", onClick);
			root.removeEventListener("keydown", onKey);
			window.removeEventListener("resize", wake);
		};
	}, [
		items,
		preset,
		intro,
		cardHeight,
		gap,
		squeeze,
		focusOnClick
	]);
	const nudge = (dir) => {
		target.current = Math.max(0, Math.min(items.length - 1, Math.round(target.current) + dir));
		wakeRef.current();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: rootRef,
			tabIndex: 0,
			"aria-roledescription": "carousel",
			"aria-label": "Events SAMEO produces",
			className: "relative min-h-0 flex-1 overflow-hidden outline-none touch-pan-y",
			children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"data-index": index,
				ref: (node) => {
					cardRefs.current[index] = node;
				},
				className: "glass-strong absolute top-0 left-0 w-3/4 max-w-md overflow-hidden rounded-[1.75rem] text-left will-change-transform",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.src,
						alt: item.alt,
						draggable: false,
						loading: index === 0 ? "eager" : "lazy",
						className: "h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 bg-gradient-to-b from-white/20 via-transparent to-ink/75" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-x-5 top-0 h-px bg-white/60" }),
					captions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute inset-x-0 bottom-0 flex flex-col gap-1 px-5 pt-12 pb-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl leading-none text-fg sm:text-4xl",
							children: item.title
						}), item.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tracking-[0.22em] text-gold uppercase",
							children: item.subtitle
						}) : null]
					}) : null
				]
			}, item.src))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-center gap-3 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Previous event",
					onClick: () => nudge(-1),
					className: "grid h-11 w-11 place-items-center rounded-full glass text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-24 text-center text-xs tracking-[0.22em] text-muted uppercase",
					children: "Drag"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Next event",
					onClick: () => nudge(1),
					className: "grid h-11 w-11 place-items-center rounded-full glass text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, { flip: true })
				})
			]
		})]
	});
}
function Chevron({ flip = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "16",
		height: "16",
		viewBox: "0 0 16 16",
		"aria-hidden": true,
		className: flip ? "rotate-180" : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 3 L5 8 L10 13",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.4"
		})
	});
}
var SVG_NS$1 = "http://www.w3.org/2000/svg";
function FluxLines({ colors = [
	"#ffffff",
	"#ffffff",
	"#ffffff"
], glow = 2, rimWidth = .2, lineWidth = 1, flowDirection = "down", mouseInteraction = false, clickSwirl = false }) {
	const svgRef = (0, import_react.useRef)(null);
	const colorKey = colors.join("|");
	(0, import_react.useEffect)(() => {
		const svg = svgRef.current;
		if (!svg) return;
		const palette = colorKey.split("|");
		const pointer = {
			x: 0,
			y: 0,
			active: false
		};
		const swirls = [];
		const rims = [];
		const cores = [];
		let frame = 0;
		let running = true;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const resize = () => {
			const w = window.innerWidth;
			const h = window.innerHeight;
			svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
		};
		resize();
		const onMove = (event) => {
			pointer.x = event.clientX;
			pointer.y = event.clientY;
			pointer.active = true;
		};
		const onLeave = () => {
			pointer.active = false;
		};
		const onClick = (event) => {
			swirls.push({
				x: event.clientX,
				y: event.clientY,
				life: 1,
				dir: Math.random() > .5 ? 1 : -1
			});
			if (swirls.length > 4) swirls.shift();
		};
		if (mouseInteraction) {
			window.addEventListener("pointermove", onMove, { passive: true });
			window.addEventListener("pointerleave", onLeave);
		}
		if (clickSwirl) window.addEventListener("click", onClick);
		window.addEventListener("resize", resize);
		const draw = (time) => {
			if (!running) return;
			const w = window.innerWidth;
			const h = window.innerHeight;
			const mobile = w < 760;
			const count = mobile ? 14 : 30;
			const segments = mobile ? 16 : 26;
			const flow = flowDirection === "up" ? -1 : 1;
			const travel = reduce ? .4 : time * 22e-5 * flow;
			const amp = mobile ? 16 : 26;
			while (cores.length < count) {
				const rim = document.createElementNS(SVG_NS$1, "path");
				const core = document.createElementNS(SVG_NS$1, "path");
				rim.setAttribute("fill", "none");
				core.setAttribute("fill", "none");
				rim.setAttribute("stroke-linecap", "round");
				core.setAttribute("stroke-linecap", "round");
				svg.append(rim, core);
				rims.push(rim);
				cores.push(core);
			}
			for (let i = 0; i < count; i++) {
				const baseX = (i + .5) / count * w;
				const color = palette[i % palette.length] ?? "#ffffff";
				let d = "";
				for (let s = 0; s <= segments; s++) {
					const u = s / segments;
					let x = baseX + Math.sin(u * 7.2 + travel * 6 + i * .55) * amp + Math.sin(u * 2.1 - travel * 3 + i) * amp * .35;
					let y = u * (h + 48) - 24;
					if (mouseInteraction && pointer.active && !mobile) {
						const dx = pointer.x - x;
						const dy = pointer.y - y;
						const pull = Math.exp(-(dx * dx + dy * dy) / 51200);
						x += dx * pull * .42;
						y += dy * pull * .08;
					}
					for (const swirl of swirls) {
						const sx = x - swirl.x;
						const sy = y - swirl.y;
						const dist = Math.hypot(sx, sy) + .001;
						const fall = Math.exp(-dist / 140) * swirl.life;
						const ang = swirl.dir * fall * 1.7;
						const cs = Math.cos(ang);
						const sn = Math.sin(ang);
						x = swirl.x + sx * cs - sy * sn;
						y = swirl.y + sx * sn + sy * cs;
					}
					d += `${s === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
				}
				const alpha = .12 + (mouseInteraction && pointer.active ? Math.exp(-((baseX - pointer.x) ** 2) / 115200) : 0) * .5;
				const rim = rims[i];
				const core = cores[i];
				if (!rim || !core) continue;
				rim.setAttribute("d", d);
				core.setAttribute("d", d);
				rim.setAttribute("stroke", withAlpha(color, alpha * .4));
				rim.setAttribute("stroke-width", String(lineWidth + rimWidth * 8 + glow * .45));
				core.setAttribute("stroke", withAlpha(color, Math.min(.9, alpha + .18)));
				core.setAttribute("stroke-width", String(Math.max(.6, lineWidth)));
				rim.style.display = "";
				core.style.display = "";
			}
			for (let i = count; i < cores.length; i++) {
				rims[i].style.display = "none";
				cores[i].style.display = "none";
			}
			if (reduce) return;
			for (const swirl of swirls) swirl.life *= .972;
			for (let i = swirls.length - 1; i >= 0; i--) if (swirls[i].life < .02) swirls.splice(i, 1);
			frame = requestAnimationFrame(draw);
		};
		const onVis = () => {
			if (document.hidden) {
				cancelAnimationFrame(frame);
				frame = 0;
				return;
			}
			if (!frame) frame = requestAnimationFrame(draw);
		};
		frame = requestAnimationFrame(draw);
		document.addEventListener("visibilitychange", onVis);
		return () => {
			running = false;
			cancelAnimationFrame(frame);
			window.removeEventListener("resize", resize);
			window.removeEventListener("pointermove", onMove);
			window.removeEventListener("pointerleave", onLeave);
			window.removeEventListener("click", onClick);
			document.removeEventListener("visibilitychange", onVis);
			for (const node of rims) node.remove();
			for (const node of cores) node.remove();
		};
	}, [
		colorKey,
		glow,
		rimWidth,
		lineWidth,
		flowDirection,
		mouseInteraction,
		clickSwirl
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		ref: svgRef,
		"aria-hidden": true,
		className: "pointer-events-none fixed inset-0 z-0 h-full w-full"
	});
}
function withAlpha(hex, alpha) {
	const raw = hex.replace("#", "");
	const full = raw.length === 3 ? raw.split("").map((c) => c + c).join("") : raw;
	const n = Number.parseInt(full, 16);
	if (Number.isNaN(n)) return `rgba(255,255,255,${alpha})`;
	return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${alpha})`;
}
var SVG_NS = "http://www.w3.org/2000/svg";
function TechText({ text, fontWeight = 500, fontSize = 120, reveal = "letter", dashLength = 4, dashGap = 2, specks = 12, intro = "none", introDuration = 2, clickKick = false, guides = false }) {
	const svgRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const kick = (0, import_react.useRef)(0);
	const [drawn, setDrawn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const svg = svgRef.current;
		const wrap = wrapRef.current;
		if (!svg || !wrap) return;
		const measurer = document.createElement("canvas").getContext("2d");
		if (!measurer) return;
		let frame = 0;
		let running = true;
		let announced = false;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const started = performance.now();
		const speckle = Array.from({ length: specks }, (_, i) => ({
			u: i * 97 % 100 / 100,
			v: i * 53 % 100 / 100,
			s: .8 + i * 17 % 8 / 8,
			p: i * .7 % (Math.PI * 2)
		}));
		const guideA = document.createElementNS(SVG_NS, "line");
		const guideB = document.createElementNS(SVG_NS, "line");
		const group = document.createElementNS(SVG_NS, "g");
		const letters = (reveal === "word" ? [text] : [...text]).map(() => {
			const node = document.createElementNS(SVG_NS, "text");
			node.setAttribute("fill", "#f6f1ea");
			node.setAttribute("stroke", "rgba(246,241,234,0.9)");
			node.setAttribute("stroke-linejoin", "round");
			node.setAttribute("font-family", "Outfit, sans-serif");
			node.setAttribute("dominant-baseline", "middle");
			group.append(node);
			return node;
		});
		const dots = speckle.map(() => {
			const node = document.createElementNS(SVG_NS, "rect");
			group.append(node);
			return node;
		});
		if (guides) {
			guideA.setAttribute("stroke", "rgba(198,163,106,0.5)");
			guideB.setAttribute("stroke", "rgba(198,163,106,0.5)");
			guideA.setAttribute("stroke-dasharray", `${dashLength} ${dashGap}`);
			guideB.setAttribute("stroke-dasharray", `${dashLength} ${dashGap}`);
			svg.append(guideA, guideB);
		}
		svg.append(group);
		const resize = () => {
			const rect = wrap.getBoundingClientRect();
			svg.setAttribute("viewBox", `0 0 ${Math.max(1, rect.width)} ${Math.max(1, rect.height)}`);
		};
		resize();
		const paint = (now) => {
			if (!running) return;
			const rect = wrap.getBoundingClientRect();
			const w = rect.width;
			const h = rect.height;
			const elapsed = Math.max(0, (now - started - kick.current) / 1e3);
			const span = Math.max(.4, introDuration);
			const global = reduce ? 1 : Math.min(1, elapsed / span);
			const rise = intro === "rise" && !reduce ? (1 - Math.min(1, elapsed / (span * .55))) * 26 : 0;
			const fitted = Math.min(fontSize, Math.max(48, w / (text.length * .72)));
			const parts = reveal === "word" ? [text] : [...text];
			measurer.font = `${fontWeight} ${fitted}px Outfit, sans-serif`;
			const widths = parts.map((ch) => measurer.measureText(ch).width);
			const tracking = fitted * .08;
			const total = widths.reduce((sum, width) => sum + width, 0) + tracking * Math.max(0, parts.length - 1);
			let x = (w - total) / 2;
			const y = h * .56 + rise;
			if (guides) {
				guideA.setAttribute("x1", String(x - 16));
				guideA.setAttribute("x2", String(x + total + 16));
				guideA.setAttribute("y1", String(y));
				guideA.setAttribute("y2", String(y));
				guideB.setAttribute("x1", String(x - 16));
				guideB.setAttribute("x2", String(x + total + 16));
				guideB.setAttribute("y1", String(y - fitted * .36));
				guideB.setAttribute("y2", String(y - fitted * .36));
			}
			parts.forEach((ch, i) => {
				const node = letters[i];
				if (!node) return;
				const stagger = reveal === "word" ? 0 : i * (span * .07);
				const local = reduce ? 1 : clamp((elapsed - stagger) / (span * .45));
				node.textContent = ch;
				node.setAttribute("x", String(x));
				node.setAttribute("y", String(y));
				node.setAttribute("font-size", String(fitted));
				node.setAttribute("font-weight", String(fontWeight));
				node.setAttribute("stroke-width", String(Math.max(1, fitted * .02)));
				node.setAttribute("stroke-dasharray", `${dashLength} ${dashGap}`);
				node.setAttribute("stroke-dashoffset", String((1 - local) * 56));
				node.setAttribute("fill-opacity", String(local));
				node.setAttribute("stroke-opacity", String(.25 + local * .75));
				x += (widths[i] ?? 0) + tracking;
			});
			const left = (w - total) / 2;
			dots.forEach((dot, i) => {
				const speck = speckle[i];
				if (!speck) return;
				const appear = reduce ? 1 : clamp((global - .2) * 1.5);
				const px = left + speck.u * total;
				const py = y - fitted * .62 + speck.v * fitted * 1.2 + Math.sin(elapsed * 1.5 + speck.p) * 3;
				dot.setAttribute("x", String(px));
				dot.setAttribute("y", String(py));
				dot.setAttribute("width", String(speck.s + .7));
				dot.setAttribute("height", String(speck.s + .7));
				dot.setAttribute("fill", i % 4 === 0 ? "#c6a36a" : "#f6f1ea");
				dot.setAttribute("opacity", String(appear * (.3 + .7 * (.5 + .5 * Math.sin(elapsed * 2.2 + i)))));
			});
			if (!announced && w > 0) {
				announced = true;
				setDrawn(true);
			}
			if (!reduce) frame = requestAnimationFrame(paint);
		};
		const start = () => {
			if (running) frame = requestAnimationFrame(paint);
		};
		document.fonts.load(`${fontWeight} 96px Outfit`).then(start);
		start();
		const onResize = () => resize();
		window.addEventListener("resize", onResize);
		const observer = new ResizeObserver(() => resize());
		observer.observe(wrap);
		const onKick = () => {
			if (!clickKick) return;
			kick.current = performance.now() - started;
		};
		if (clickKick) wrap.addEventListener("click", onKick);
		return () => {
			running = false;
			cancelAnimationFrame(frame);
			window.removeEventListener("resize", onResize);
			observer.disconnect();
			wrap.removeEventListener("click", onKick);
			guideA.remove();
			guideB.remove();
			group.remove();
		};
	}, [
		text,
		fontWeight,
		fontSize,
		reveal,
		dashLength,
		dashGap,
		specks,
		intro,
		introDuration,
		clickKick,
		guides
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: clickKick ? "relative h-full w-full cursor-pointer" : "relative h-full w-full",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: drawn ? "sr-only" : "pointer-events-none absolute inset-0 flex items-center justify-center font-sans text-7xl font-medium tracking-widest text-fg sm:text-8xl md:text-9xl",
			children: text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			ref: svgRef,
			"aria-hidden": true,
			className: "relative h-full w-full overflow-visible"
		})]
	});
}
function clamp(value) {
	return Math.max(0, Math.min(1, value));
}
var services = [
	{
		index: "01",
		title: "Sound Systems",
		copy: "L-Acoustics Kara II delays and subs, Audio Center Avanda mains, Mackie side fill, and Midas M32 at front of house."
	},
	{
		index: "02",
		title: "Lighting Solutions",
		copy: "Moving heads and washes, blinders, facelights, profiles, haze and a 5W laser, programmed from an Arena console."
	},
	{
		index: "03",
		title: "Truss & Stage",
		copy: "Box truss, delay towers, motors and rigging, with an 18×10 platform, ramp, black carpet, skirting and steps."
	},
	{
		index: "04",
		title: "LED Display Screens",
		copy: "Outdoor P3 and indoor P2 fine-pitch walls, high brightness, side walls, processors, switcher and J6."
	},
	{
		index: "05",
		title: "Event Support",
		copy: "Show control from laptop to VJ, power distribution, wireless and wired microphones, stands and full cabling."
	},
	{
		index: "06",
		title: "Professional Technicians",
		copy: "Sound technicians and engineers, lighting engineers and AC technicians on the floor for the whole call."
	}
];
var events = [
	{
		src: "/images/corporate.jpg",
		alt: "A dark corporate gala stage with a warm LED wall and glass tables",
		title: "Corporate Events",
		subtitle: "Functions & galas"
	},
	{
		src: "/images/concert.jpg",
		alt: "A concert rig with line arrays, truss and beams through haze",
		title: "Concerts & Live Shows",
		subtitle: "Arenas & rooms"
	},
	{
		src: "/images/exhibition.jpg",
		alt: "A trade-show hall with black booths and glowing LED screens",
		title: "Exhibitions & Trade Shows",
		subtitle: "Halls & booths"
	},
	{
		src: "/images/wedding.jpg",
		alt: "An evening wedding reception with warm uplight and banquet tables",
		title: "Weddings & Private Functions",
		subtitle: "Rooms held quietly"
	},
	{
		src: "/images/festival.jpg",
		alt: "An outdoor night festival stage with truss, delay and a distant crowd",
		title: "Outdoor Events & Festivals",
		subtitle: "Open air"
	},
	{
		src: "/images/launch.jpg",
		alt: "A minimal product-launch stage with a seamless gold LED backdrop",
		title: "Product Launches",
		subtitle: "One clean picture"
	}
];
var rider = [
	{
		id: "sound",
		index: "01",
		title: "Sound System",
		lede: "Main PA, delays, consoles and side fill.",
		rows: [
			{
				name: "L-Acoustics Kara II Tops",
				spec: "Delay",
				qty: "12"
			},
			{
				name: "L-Acoustics Subs",
				spec: "18\"",
				qty: "6"
			},
			{
				name: "L-Acoustics LA12X Amplifiers",
				spec: "Drive",
				qty: "4"
			},
			{
				name: "Audio Center Avanda 210 Tops",
				spec: "Main PA",
				qty: "12"
			},
			{
				name: "Audio Center Dual Subs",
				spec: "Low end",
				qty: "6"
			},
			{
				name: "Midas M32 Live",
				spec: "Console",
				qty: "2"
			},
			{
				name: "Mackie DRM",
				spec: "Double top side fill",
				qty: "2"
			},
			{
				name: "Flybar",
				spec: "Hang",
				qty: "4"
			}
		]
	},
	{
		id: "mics",
		index: "02",
		title: "Mic & Accessories",
		lede: "Wireless, cord, stands and the copper that ties the show together.",
		rows: [
			{
				name: "Shure SLXD4",
				spec: "Wireless mic",
				qty: "4"
			},
			{
				name: "Shure Headset",
				spec: "Wireless",
				qty: "2"
			},
			{
				name: "SM58, SM57",
				spec: "Cord mic",
				qty: "As ordered"
			},
			{
				name: "Mic Stands",
				spec: "Big & small",
				qty: "12"
			},
			{
				name: "Notation Stands",
				spec: "Music",
				qty: "2"
			},
			{
				name: "DI Box",
				spec: "Active / passive",
				qty: "As ordered"
			},
			{
				name: "Cable & Accessories",
				spec: "Looms",
				qty: "Lot"
			},
			{
				name: "Power Distribution",
				spec: "Distro",
				qty: "2"
			}
		]
	},
	{
		id: "lighting",
		index: "03",
		title: "Lighting",
		lede: "A full conventional and moving plot, plus atmosphere.",
		rows: [
			{
				name: "Moving Head",
				spec: "Spot",
				qty: "24"
			},
			{
				name: "Moving Wash",
				spec: "Wash",
				qty: "30"
			},
			{
				name: "LED Parcans",
				spec: "Wash",
				qty: "80"
			},
			{
				name: "Blinder",
				spec: "Audience",
				qty: "24"
			},
			{
				name: "Laser",
				spec: "5W",
				qty: "1"
			},
			{
				name: "Facelight",
				spec: "Key",
				qty: "24"
			},
			{
				name: "Profile",
				spec: "Ellipsoidal",
				qty: "4"
			},
			{
				name: "Haze",
				spec: "Atmosphere",
				qty: "3"
			},
			{
				name: "Lighting Console",
				spec: "Arena",
				qty: "1"
			},
			{
				name: "Cables & Accessories",
				spec: "Data & power",
				qty: "Lot"
			}
		]
	},
	{
		id: "truss",
		index: "04",
		title: "Truss & Rigging",
		lede: "The structure the light and the picture hang from.",
		rows: [
			{
				name: "Box Truss",
				spec: "20×12",
				qty: "System"
			},
			{
				name: "Delay Screen Truss",
				spec: "5×5",
				qty: "2"
			},
			{
				name: "Motors",
				spec: "Chain hoists",
				qty: "20"
			},
			{
				name: "Rigging Accessories",
				spec: "Steel & spansets",
				qty: "Lot"
			}
		]
	},
	{
		id: "stage",
		index: "05",
		title: "Stage",
		lede: "Platform, access and a black finish that disappears.",
		rows: [
			{
				name: "Stage Platform",
				spec: "18×10×1",
				qty: "1"
			},
			{
				name: "Ramp",
				spec: "3×2",
				qty: "1"
			},
			{
				name: "Carpet",
				spec: "Black",
				qty: "Full"
			},
			{
				name: "Skirting",
				spec: "Black",
				qty: "Full"
			},
			{
				name: "Steps",
				spec: "Side",
				qty: "2"
			},
			{
				name: "Backstage Steps",
				spec: "Rear access",
				qty: "2"
			}
		]
	},
	{
		id: "led",
		index: "06",
		title: "LED & Video",
		lede: "Outdoor P3, indoor P2 fine pitch, high brightness, and the desk behind the picture.",
		rows: [
			{
				name: "Outdoor LED Screen",
				spec: "P3",
				qty: "Available"
			},
			{
				name: "Indoor LED Screen",
				spec: "P2 · fine pitch",
				qty: "Available"
			},
			{
				name: "LED Wall",
				spec: "18×4",
				qty: "1"
			},
			{
				name: "LED Side Wall",
				spec: "4×3",
				qty: "Pair"
			},
			{
				name: "Laptop",
				spec: "Playback",
				qty: "2"
			},
			{
				name: "Processor",
				spec: "LED",
				qty: "4"
			},
			{
				name: "J6",
				spec: "Processor",
				qty: "1"
			},
			{
				name: "Switcher",
				spec: "Video",
				qty: "1"
			},
			{
				name: "VJ",
				spec: "Operator",
				qty: "1"
			}
		]
	}
];
var crew = [
	"Sound Technician",
	"Sound Engineer",
	"Light Engineer",
	"AC Technician"
];
var LINE_COLORS = [
	"#ffffff",
	"#ffffff",
	"#f6f1ea"
];
var serviceIcons = [
	AudioLines,
	Sun,
	Box,
	MonitorPlay,
	LifeBuoy,
	Users
];
var chapters = [
	{
		id: "vision",
		label: "Vision"
	},
	{
		id: "expertise",
		label: "Expertise"
	},
	{
		id: "events",
		label: "Events"
	},
	{
		id: "inventory",
		label: "Rider"
	},
	{
		id: "contact",
		label: "Contact"
	}
];
var facts = [
	{
		k: "Outdoor",
		v: "LED P3"
	},
	{
		k: "Indoor",
		v: "LED P2"
	},
	{
		k: "Picture",
		v: "Fine pitch"
	},
	{
		k: "Output",
		v: "High brightness"
	}
];
function SameoPortfolio() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)("vision");
	const [progress, setProgress] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const nodes = chapters.map((chapter) => document.getElementById(chapter.id)).filter((node) => Boolean(node));
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			threshold: [.25, .45],
			rootMargin: "-18% 0px -40% 0px"
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		const onScroll = () => {
			if (frame) return;
			frame = requestAnimationFrame(() => {
				const max = document.documentElement.scrollHeight - window.innerHeight;
				setProgress(max > 0 ? window.scrollY / max : 0);
				frame = 0;
			});
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => {
			window.removeEventListener("scroll", onScroll);
			cancelAnimationFrame(frame);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FluxLines, {
				colors: LINE_COLORS,
				glow: 2,
				rimWidth: .2,
				lineWidth: 1,
				flowDirection: "down",
				mouseInteraction: true,
				clickSwirl: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "fixed inset-x-0 top-0 z-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 md:px-6 md:py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#vision",
							className: "glass rounded-full px-4 py-2 font-display text-lg tracking-[0.22em]",
							children: "SAMEO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "glass hidden items-center rounded-full p-1 md:flex",
							"aria-label": "Primary",
							children: chapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `#${chapter.id}`,
								className: active === chapter.id ? "rounded-full bg-fg px-4 py-2 text-xs tracking-[0.16em] text-ink uppercase" : "rounded-full px-4 py-2 text-xs tracking-[0.16em] text-muted uppercase",
								children: chapter.label
							}, chapter.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							className: "hidden h-11 items-center rounded-full bg-fg px-5 text-xs font-medium tracking-[0.16em] text-ink uppercase md:inline-flex",
							children: "Contact"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "glass grid h-11 w-11 place-items-center rounded-full md:hidden",
							"aria-expanded": open,
							"aria-label": open ? "Close menu" : "Open menu",
							onClick: () => setOpen((value) => !value),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex w-4 flex-col gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: open ? "h-px w-4 bg-fg translate-y-[3.5px] rotate-45" : "h-px w-4 bg-fg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: open ? "h-px w-4 bg-fg -translate-y-[3.5px] -rotate-45" : "h-px w-4 bg-fg" })]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-px bg-white/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-px origin-left bg-gold",
						style: { transform: `scaleX(${progress})` }
					})
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nav-sheet fixed inset-0 z-30 flex flex-col justify-end bg-bg/70 px-4 pt-24 backdrop-blur-2xl md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "glass-strong rounded-[1.75rem] p-3",
					"aria-label": "Mobile",
					children: chapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `#${chapter.id}`,
						onClick: () => setOpen(false),
						className: "flex h-14 items-center justify-between border-b border-line px-4 text-lg last:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: chapter.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs tracking-[0.18em] text-gold uppercase",
							children: ["0", chapters.indexOf(chapter) + 1]
						})]
					}, chapter.id))
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed top-1/2 right-3 z-30 hidden -translate-y-1/2 flex-col lg:flex",
				"aria-label": "Chapters",
				children: chapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `#${chapter.id}`,
					className: "grid h-11 w-11 place-items-center",
					"aria-label": chapter.label,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: active === chapter.id ? "h-7 w-px bg-gold" : "h-4 w-px bg-white/30" })
				}, chapter.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "vision",
						className: "flex min-h-svh flex-col justify-center px-5 pt-24 pb-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex w-full max-w-5xl flex-col items-center text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rise-in text-xs tracking-[0.42em] text-gold uppercase",
									children: "AV & Events Solutions"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mark-stage mt-4 w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "h-full",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TechText, {
											text: "SAMEO",
											fontWeight: 600,
											fontSize: 150,
											reveal: "letter",
											dashLength: 4,
											dashGap: 2,
											specks: 15,
											intro: "none",
											introDuration: 2,
											clickKick: true,
											guides: false
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rise-in font-display text-3xl text-fg sm:text-5xl",
									children: "Your vision. Our expertise."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rise-in mt-5 max-w-xl text-base text-muted sm:text-lg",
									children: "Professional AV solutions for events of every size — from corporate functions to concerts, exhibitions and more."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 flex flex-wrap items-center justify-center gap-2",
									children: [
										"Sound",
										"Lighting",
										"Truss",
										"LED",
										"Stage",
										"Crew"
									].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "glass rounded-full px-4 py-2 text-xs tracking-[0.18em] text-fg uppercase",
										children: item
									}, item))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "expertise",
						className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
								index: "01",
								kicker: "What we bring",
								title: "The floor, fully dressed."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
								children: services.map((service, index) => {
									const Icon = serviceIcons[index] ?? AudioLines;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "glass rounded-[1.75rem] p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "grid h-11 w-11 place-items-center rounded-full border border-line text-gold",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
														size: 18,
														strokeWidth: 1.5
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-display text-2xl text-gold/80",
													children: service.index
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-8 font-display text-3xl leading-none",
												children: service.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-4 text-sm leading-6 text-muted",
												children: service.copy
											})
										]
									}, service.title);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4",
								children: facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "glass rounded-[1.75rem] px-5 py-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs tracking-[0.2em] text-muted uppercase",
										children: fact.k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-2 font-display text-2xl",
										children: fact.v
									})]
								}, fact.v))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "events",
						className: "mx-auto max-w-6xl px-5 py-12 md:px-6 md:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
							index: "02",
							kicker: "Where it plays",
							title: "Every room. Same standard."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "event-stage mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlexCarousel, {
								items: events,
								preset: "liquid",
								intro: "rise",
								cardHeight: .72,
								gap: 12,
								squeeze: .2,
								focusOnClick: true,
								captions: true
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "inventory",
						className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
								index: "03",
								kicker: "House rider",
								title: "What is actually on the truck."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-xl text-muted",
								children: "Quantities from the working inventory — sound, light, truss, stage, LED and the people who run them."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 grid gap-4 lg:grid-cols-2",
								children: [rider.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									id: group.id,
									className: "glass rounded-[1.75rem] p-6 md:p-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-[0.22em] text-gold uppercase",
											children: group.index
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-2 font-display text-4xl",
											children: group.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-muted",
											children: group.lede
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-6",
											children: group.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-4 border-t border-line py-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block text-fg",
														children: row.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sm text-muted",
														children: row.spec
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm tracking-wide text-gold",
													children: row.qty
												})]
											}, `${group.id}-${row.name}`))
										})
									]
								}, group.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "glass-strong rounded-[1.75rem] p-6 md:p-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-[0.22em] text-gold uppercase",
											children: "07"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-2 font-display text-4xl",
											children: "Event Crew"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-muted",
											children: "The call sheet that shows up with the gear."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-6",
											children: crew.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-center justify-between border-t border-line py-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: role }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs tracking-[0.18em] text-gold uppercase",
													children: "On site"
												})]
											}, role))
										})
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "contact",
						className: "mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-[0.28em] text-gold uppercase",
								children: "Contact"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 max-w-3xl font-display text-5xl leading-none sm:text-7xl",
								children: "Let's make your event unforgettable."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 grid gap-3 md:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "tel:0563104314",
									className: "glass rounded-[1.75rem] p-6 transition-transform duration-200 hover:-translate-y-0.5 md:p-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs tracking-[0.22em] text-muted uppercase",
										children: "Call"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-3 block font-display text-4xl sm:text-5xl",
										children: "056 310 4314"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:muhammadsami2026@gmail.com",
									className: "glass rounded-[1.75rem] p-6 transition-transform duration-200 hover:-translate-y-0.5 md:p-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs tracking-[0.22em] text-muted uppercase",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-3 block font-display text-3xl break-all sm:text-4xl",
										children: "muhammadsami2026@gmail.com"
									})]
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "relative z-10 mx-auto flex max-w-6xl flex-col gap-2 px-5 py-10 text-sm text-muted md:flex-row md:items-center md:justify-between md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tracking-[0.22em] text-fg uppercase",
					children: "SAMEO"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "AV & Events Solutions" })]
			})
		]
	});
}
function SectionHead({ index, kicker, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-3xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs tracking-[0.28em] text-gold uppercase",
			children: [
				index,
				" — ",
				kicker
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-3 font-display text-5xl leading-none sm:text-6xl",
			children: title
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SameoPortfolio, {});
}
//#endregion
export { Home as component };
