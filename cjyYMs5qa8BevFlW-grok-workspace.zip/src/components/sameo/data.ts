export type RiderRow = {
  name: string;
  spec: string;
  qty: string;
};

export type RiderGroup = {
  id: string;
  index: string;
  title: string;
  lede: string;
  rows: RiderRow[];
};

export const services = [
  {
    index: "01",
    title: "Sound Systems",
    copy: "L-Acoustics Kara II delays and subs, Audio Center Avanda mains, Mackie side fill, and Midas M32 at front of house.",
  },
  {
    index: "02",
    title: "Lighting Solutions",
    copy: "Moving heads and washes, blinders, facelights, profiles, haze and a 5W laser, programmed from an Arena console.",
  },
  {
    index: "03",
    title: "Truss & Stage",
    copy: "Box truss, delay towers, motors and rigging, with an 18×10 platform, ramp, black carpet, skirting and steps.",
  },
  {
    index: "04",
    title: "LED Display Screens",
    copy: "Outdoor P3 and indoor P2 fine-pitch walls, high brightness, side walls, processors, switcher and J6.",
  },
  {
    index: "05",
    title: "Event Support",
    copy: "Show control from laptop to VJ, power distribution, wireless and wired microphones, stands and full cabling.",
  },
  {
    index: "06",
    title: "Professional Technicians",
    copy: "Sound technicians and engineers, lighting engineers and AC technicians on the floor for the whole call.",
  },
] as const;

export const events = [
  {
    src: "/images/corporate.jpg",
    alt: "A dark corporate gala stage with a warm LED wall and glass tables",
    title: "Corporate Events",
    subtitle: "Functions & galas",
  },
  {
    src: "/images/concert.jpg",
    alt: "A concert rig with line arrays, truss and beams through haze",
    title: "Concerts & Live Shows",
    subtitle: "Arenas & rooms",
  },
  {
    src: "/images/exhibition.jpg",
    alt: "A trade-show hall with black booths and glowing LED screens",
    title: "Exhibitions & Trade Shows",
    subtitle: "Halls & booths",
  },
  {
    src: "/images/wedding.jpg",
    alt: "An evening wedding reception with warm uplight and banquet tables",
    title: "Weddings & Private Functions",
    subtitle: "Rooms held quietly",
  },
  {
    src: "/images/festival.jpg",
    alt: "An outdoor night festival stage with truss, delay and a distant crowd",
    title: "Outdoor Events & Festivals",
    subtitle: "Open air",
  },
  {
    src: "/images/launch.jpg",
    alt: "A minimal product-launch stage with a seamless gold LED backdrop",
    title: "Product Launches",
    subtitle: "One clean picture",
  },
] as const;

export const rider: RiderGroup[] = [
  {
    id: "sound",
    index: "01",
    title: "Sound System",
    lede: "Main PA, delays, consoles and side fill.",
    rows: [
      { name: "L-Acoustics Kara II Tops", spec: "Delay", qty: "12" },
      { name: "L-Acoustics Subs", spec: '18"', qty: "6" },
      { name: "L-Acoustics LA12X Amplifiers", spec: "Drive", qty: "4" },
      { name: "Audio Center Avanda 210 Tops", spec: "Main PA", qty: "12" },
      { name: "Audio Center Dual Subs", spec: "Low end", qty: "6" },
      { name: "Midas M32 Live", spec: "Console", qty: "2" },
      { name: "Mackie DRM", spec: "Double top side fill", qty: "2" },
      { name: "Flybar", spec: "Hang", qty: "4" },
    ],
  },
  {
    id: "mics",
    index: "02",
    title: "Mic & Accessories",
    lede: "Wireless, cord, stands and the copper that ties the show together.",
    rows: [
      { name: "Shure SLXD4", spec: "Wireless mic", qty: "4" },
      { name: "Shure Headset", spec: "Wireless", qty: "2" },
      { name: "SM58, SM57", spec: "Cord mic", qty: "As ordered" },
      { name: "Mic Stands", spec: "Big & small", qty: "12" },
      { name: "Notation Stands", spec: "Music", qty: "2" },
      { name: "DI Box", spec: "Active / passive", qty: "As ordered" },
      { name: "Cable & Accessories", spec: "Looms", qty: "Lot" },
      { name: "Power Distribution", spec: "Distro", qty: "2" },
    ],
  },
  {
    id: "lighting",
    index: "03",
    title: "Lighting",
    lede: "A full conventional and moving plot, plus atmosphere.",
    rows: [
      { name: "Moving Head", spec: "Spot", qty: "24" },
      { name: "Moving Wash", spec: "Wash", qty: "30" },
      { name: "LED Parcans", spec: "Wash", qty: "80" },
      { name: "Blinder", spec: "Audience", qty: "24" },
      { name: "Laser", spec: "5W", qty: "1" },
      { name: "Facelight", spec: "Key", qty: "24" },
      { name: "Profile", spec: "Ellipsoidal", qty: "4" },
      { name: "Haze", spec: "Atmosphere", qty: "3" },
      { name: "Lighting Console", spec: "Arena", qty: "1" },
      { name: "Cables & Accessories", spec: "Data & power", qty: "Lot" },
    ],
  },
  {
    id: "truss",
    index: "04",
    title: "Truss & Rigging",
    lede: "The structure the light and the picture hang from.",
    rows: [
      { name: "Box Truss", spec: "20×12", qty: "System" },
      { name: "Delay Screen Truss", spec: "5×5", qty: "2" },
      { name: "Motors", spec: "Chain hoists", qty: "20" },
      { name: "Rigging Accessories", spec: "Steel & spansets", qty: "Lot" },
    ],
  },
  {
    id: "stage",
    index: "05",
    title: "Stage",
    lede: "Platform, access and a black finish that disappears.",
    rows: [
      { name: "Stage Platform", spec: "18×10×1", qty: "1" },
      { name: "Ramp", spec: "3×2", qty: "1" },
      { name: "Carpet", spec: "Black", qty: "Full" },
      { name: "Skirting", spec: "Black", qty: "Full" },
      { name: "Steps", spec: "Side", qty: "2" },
      { name: "Backstage Steps", spec: "Rear access", qty: "2" },
    ],
  },
  {
    id: "led",
    index: "06",
    title: "LED & Video",
    lede: "Outdoor P3, indoor P2 fine pitch, high brightness, and the desk behind the picture.",
    rows: [
      { name: "Outdoor LED Screen", spec: "P3", qty: "Available" },
      { name: "Indoor LED Screen", spec: "P2 · fine pitch", qty: "Available" },
      { name: "LED Wall", spec: "18×4", qty: "1" },
      { name: "LED Side Wall", spec: "4×3", qty: "Pair" },
      { name: "Laptop", spec: "Playback", qty: "2" },
      { name: "Processor", spec: "LED", qty: "4" },
      { name: "J6", spec: "Processor", qty: "1" },
      { name: "Switcher", spec: "Video", qty: "1" },
      { name: "VJ", spec: "Operator", qty: "1" },
    ],
  },
];

export const crew = [
  "Sound Technician",
  "Sound Engineer",
  "Light Engineer",
  "AC Technician",
] as const;
