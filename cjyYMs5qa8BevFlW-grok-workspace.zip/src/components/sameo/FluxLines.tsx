import { useEffect, useRef } from "react";

type FluxLinesProps = {
  colors?: string[];
  glow?: number;
  rimWidth?: number;
  lineWidth?: number;
  flowDirection?: "down" | "up";
  mouseInteraction?: boolean;
  clickSwirl?: boolean;
};

type Swirl = { x: number; y: number; life: number; dir: number };

const SVG_NS = "http://www.w3.org/2000/svg";

export default function FluxLines({
  colors = ["#ffffff", "#ffffff", "#ffffff"],
  glow = 2,
  rimWidth = 0.2,
  lineWidth = 1,
  flowDirection = "down",
  mouseInteraction = false,
  clickSwirl = false,
}: FluxLinesProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const colorKey = colors.join("|");

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;

    const palette = colorKey.split("|");
    const pointer = { x: 0, y: 0, active: false };
    const swirls: Swirl[] = [];
    const rims: SVGPathElement[] = [];
    const cores: SVGPathElement[] = [];
    let frame = 0;
    let running = true;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const resize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
    };
    resize();

    const onMove = (event: PointerEvent) => {
      pointer.x = event.clientX;
      pointer.y = event.clientY;
      pointer.active = true;
    };
    const onLeave = () => {
      pointer.active = false;
    };
    const onClick = (event: MouseEvent) => {
      swirls.push({
        x: event.clientX,
        y: event.clientY,
        life: 1,
        dir: Math.random() > 0.5 ? 1 : -1,
      });
      if (swirls.length > 4) swirls.shift();
    };

    if (mouseInteraction) {
      window.addEventListener("pointermove", onMove, { passive: true });
      window.addEventListener("pointerleave", onLeave);
    }
    if (clickSwirl) window.addEventListener("click", onClick);
    window.addEventListener("resize", resize);

    const draw = (time: number) => {
      if (!running) return;
      const w = window.innerWidth;
      const h = window.innerHeight;
      const mobile = w < 760;
      const count = mobile ? 14 : 30;
      const segments = mobile ? 16 : 26;
      const flow = flowDirection === "up" ? -1 : 1;
      const travel = reduce ? 0.4 : time * 0.00022 * flow;
      const amp = mobile ? 16 : 26;

      while (cores.length < count) {
        const rim = document.createElementNS(SVG_NS, "path");
        const core = document.createElementNS(SVG_NS, "path");
        rim.setAttribute("fill", "none");
        core.setAttribute("fill", "none");
        rim.setAttribute("stroke-linecap", "round");
        core.setAttribute("stroke-linecap", "round");
        svg.append(rim, core);
        rims.push(rim);
        cores.push(core);
      }

      for (let i = 0; i < count; i++) {
        const baseX = ((i + 0.5) / count) * w;
        const color = palette[i % palette.length] ?? "#ffffff";
        let d = "";
        for (let s = 0; s <= segments; s++) {
          const u = s / segments;
          let x =
            baseX +
            Math.sin(u * 7.2 + travel * 6 + i * 0.55) * amp +
            Math.sin(u * 2.1 - travel * 3 + i) * amp * 0.35;
          let y = u * (h + 48) - 24;

          if (mouseInteraction && pointer.active && !mobile) {
            const dx = pointer.x - x;
            const dy = pointer.y - y;
            const pull = Math.exp(-(dx * dx + dy * dy) / (2 * 160 * 160));
            x += dx * pull * 0.42;
            y += dy * pull * 0.08;
          }

          for (const swirl of swirls) {
            const sx = x - swirl.x;
            const sy = y - swirl.y;
            const dist = Math.hypot(sx, sy) + 0.001;
            const fall = Math.exp(-dist / 140) * swirl.life;
            const ang = swirl.dir * fall * 1.7;
            const cs = Math.cos(ang);
            const sn = Math.sin(ang);
            x = swirl.x + sx * cs - sy * sn;
            y = swirl.y + sx * sn + sy * cs;
          }

          d += `${s === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
        }

        const near =
          mouseInteraction && pointer.active ? Math.exp(-((baseX - pointer.x) ** 2) / (2 * 240 * 240)) : 0;
        const alpha = 0.12 + near * 0.5;
        const rim = rims[i];
        const core = cores[i];
        if (!rim || !core) continue;
        rim.setAttribute("d", d);
        core.setAttribute("d", d);
        rim.setAttribute("stroke", withAlpha(color, alpha * 0.4));
        rim.setAttribute("stroke-width", String(lineWidth + rimWidth * 8 + glow * 0.45));
        core.setAttribute("stroke", withAlpha(color, Math.min(0.9, alpha + 0.18)));
        core.setAttribute("stroke-width", String(Math.max(0.6, lineWidth)));
        rim.style.display = "";
        core.style.display = "";
      }

      for (let i = count; i < cores.length; i++) {
        rims[i].style.display = "none";
        cores[i].style.display = "none";
      }

      if (reduce) return;
      for (const swirl of swirls) swirl.life *= 0.972;
      for (let i = swirls.length - 1; i >= 0; i--) {
        if (swirls[i].life < 0.02) swirls.splice(i, 1);
      }
      frame = requestAnimationFrame(draw);
    };

    const onVis = () => {
      if (document.hidden) {
        cancelAnimationFrame(frame);
        frame = 0;
        return;
      }
      if (!frame) frame = requestAnimationFrame(draw);
    };

    frame = requestAnimationFrame(draw);
    document.addEventListener("visibilitychange", onVis);

    return () => {
      running = false;
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("click", onClick);
      document.removeEventListener("visibilitychange", onVis);
      for (const node of rims) node.remove();
      for (const node of cores) node.remove();
    };
  }, [colorKey, glow, rimWidth, lineWidth, flowDirection, mouseInteraction, clickSwirl]);

  return <svg ref={svgRef} aria-hidden className="pointer-events-none fixed inset-0 z-0 h-full w-full" />;
}

function withAlpha(hex: string, alpha: number) {
  const raw = hex.replace("#", "");
  const full = raw.length === 3 ? raw.split("").map((c) => c + c).join("") : raw;
  const n = Number.parseInt(full, 16);
  if (Number.isNaN(n)) return `rgba(255,255,255,${alpha})`;
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
