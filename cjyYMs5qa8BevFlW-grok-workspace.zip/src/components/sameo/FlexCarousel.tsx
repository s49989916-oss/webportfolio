import { useEffect, useRef } from "react";

export type FlexCarouselItem = {
  src: string;
  alt: string;
  title: string;
  subtitle?: string;
};

type FlexCarouselProps = {
  items: readonly FlexCarouselItem[];
  preset?: "liquid";
  intro?: "rise" | "none";
  cardHeight?: number;
  gap?: number;
  squeeze?: number;
  focusOnClick?: boolean;
  captions?: boolean;
};

export default function FlexCarousel({
  items,
  preset = "liquid",
  intro = "none",
  cardHeight = 0.62,
  gap = 12,
  squeeze = 0.2,
  focusOnClick = false,
  captions = false,
}: FlexCarouselProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const focus = useRef(0);
  const target = useRef(0);
  const wakeRef = useRef<() => void>(() => {});
  const drag = useRef({
    active: false,
    moved: false,
    originX: 0,
    originFocus: 0,
    step: 240,
  });

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    let frame = 0;
    let running = true;
    const introStart = performance.now();
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const metrics = () => {
      const rect = root.getBoundingClientRect();
      const cardH = Math.max(180, rect.height * cardHeight);
      const cardW = Math.min(rect.width * 0.78, cardH * 1.45);
      const step = cardW * (1 - squeeze * 0.85) + gap;
      return { rect, cardH, cardW, step };
    };

    const layout = () => {
      const { rect, cardH, cardW, step } = metrics();
      drag.current.step = step;
      const elapsed = (performance.now() - introStart) / 1000;
      const introT = intro === "rise" && !reduce ? Math.min(1, elapsed / 0.9) : 1;
      const ease = 1 - (1 - introT) ** 3;

      items.forEach((_, i) => {
        const el = cardRefs.current[i];
        if (!el) return;
        const offset = i - focus.current;
        const abs = Math.abs(offset);
        const scale = Math.max(0.74, 1 - Math.min(abs, 1.6) * squeeze);
        const rot = preset === "liquid" ? offset * -7 : 0;
        const x = rect.width / 2 + offset * step - cardW / 2;
        const y = (rect.height - cardH) / 2 + (1 - ease) * (26 + i * 5);
        el.style.width = `${cardW}px`;
        el.style.height = `${cardH}px`;
        el.style.opacity = String((abs > 2.45 ? 0 : 1) * ease);
        el.style.zIndex = String(30 - Math.round(abs * 3));
        el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale}) rotate(${rot}deg)`;
      });
    };

    const tick = () => {
      if (!running) return;
      if (!drag.current.active) {
        focus.current += (target.current - focus.current) * (reduce ? 1 : 0.14);
        if (Math.abs(target.current - focus.current) < 0.001) focus.current = target.current;
      }
      layout();
      const introLive = intro === "rise" && !reduce && performance.now() - introStart < 1100;
      const moving = Math.abs(target.current - focus.current) > 0.001 || drag.current.active || introLive;
      frame = moving ? requestAnimationFrame(tick) : 0;
    };

    const wake = () => {
      if (!frame) frame = requestAnimationFrame(tick);
    };
    wakeRef.current = wake;
    wake();

    const clampIndex = (value: number) => Math.max(0, Math.min(items.length - 1, value));

    const onPointerDown = (event: PointerEvent) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      const { step } = metrics();
      drag.current.active = true;
      drag.current.moved = false;
      drag.current.originX = event.clientX;
      drag.current.originFocus = focus.current;
      drag.current.step = step;
      root.setPointerCapture(event.pointerId);
    };

    const onPointerMove = (event: PointerEvent) => {
      if (!drag.current.active) return;
      const dx = event.clientX - drag.current.originX;
      if (Math.abs(dx) > 8) drag.current.moved = true;
      const next = clampIndex(drag.current.originFocus - dx / drag.current.step);
      focus.current = next;
      target.current = next;
      wake();
    };

    const onPointerUp = (event: PointerEvent) => {
      if (!drag.current.active) return;
      drag.current.active = false;
      if (root.hasPointerCapture(event.pointerId)) root.releasePointerCapture(event.pointerId);
      target.current = clampIndex(Math.round(focus.current));
      wake();
    };

    const onClick = (event: MouseEvent) => {
      const moved = drag.current.moved;
      drag.current.moved = false;
      if (!focusOnClick || moved) return;
      const button = (event.target as HTMLElement | null)?.closest("button[data-index]");
      if (!button) return;
      const index = Number(button.getAttribute("data-index"));
      if (!Number.isFinite(index)) return;
      target.current = index;
      wake();
    };

    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
      event.preventDefault();
      target.current = clampIndex(Math.round(target.current) + (event.key === "ArrowRight" ? 1 : -1));
      wake();
    };

    root.addEventListener("pointerdown", onPointerDown);
    root.addEventListener("pointermove", onPointerMove);
    root.addEventListener("pointerup", onPointerUp);
    root.addEventListener("pointercancel", onPointerUp);
    root.addEventListener("click", onClick);
    root.addEventListener("keydown", onKey);
    window.addEventListener("resize", wake);

    return () => {
      running = false;
      if (frame) cancelAnimationFrame(frame);
      root.removeEventListener("pointerdown", onPointerDown);
      root.removeEventListener("pointermove", onPointerMove);
      root.removeEventListener("pointerup", onPointerUp);
      root.removeEventListener("pointercancel", onPointerUp);
      root.removeEventListener("click", onClick);
      root.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", wake);
    };
  }, [items, preset, intro, cardHeight, gap, squeeze, focusOnClick]);

  const nudge = (dir: number) => {
    target.current = Math.max(0, Math.min(items.length - 1, Math.round(target.current) + dir));
    wakeRef.current();
  };

  return (
    <div className="flex h-full flex-col">
      <div
        ref={rootRef}
        tabIndex={0}
        aria-roledescription="carousel"
        aria-label="Events SAMEO produces"
        className="relative min-h-0 flex-1 overflow-hidden outline-none touch-pan-y"
      >
        {items.map((item, index) => (
          <button
            key={item.src}
            type="button"
            data-index={index}
            ref={(node) => {
              cardRefs.current[index] = node;
            }}
            className="glass-strong absolute top-0 left-0 w-3/4 max-w-md overflow-hidden rounded-[1.75rem] text-left will-change-transform"
          >
            <img
              src={item.src}
              alt={item.alt}
              draggable={false}
              loading={index === 0 ? "eager" : "lazy"}
              className="h-full w-full object-cover"
            />
            <span className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/20 via-transparent to-ink/75" />
            <span className="pointer-events-none absolute inset-x-5 top-0 h-px bg-white/60" />
            {captions ? (
              <span className="absolute inset-x-0 bottom-0 flex flex-col gap-1 px-5 pt-12 pb-5">
                <span className="font-display text-3xl leading-none text-fg sm:text-4xl">{item.title}</span>
                {item.subtitle ? (
                  <span className="text-xs tracking-[0.22em] text-gold uppercase">{item.subtitle}</span>
                ) : null}
              </span>
            ) : null}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-center gap-3 pt-4">
        <button
          type="button"
          aria-label="Previous event"
          onClick={() => nudge(-1)}
          className="grid h-11 w-11 place-items-center rounded-full glass text-fg"
        >
          <Chevron />
        </button>
        <p className="min-w-24 text-center text-xs tracking-[0.22em] text-muted uppercase">Drag</p>
        <button
          type="button"
          aria-label="Next event"
          onClick={() => nudge(1)}
          className="grid h-11 w-11 place-items-center rounded-full glass text-fg"
        >
          <Chevron flip />
        </button>
      </div>
    </div>
  );
}

function Chevron({ flip = false }: { flip?: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden className={flip ? "rotate-180" : undefined}>
      <path d="M10 3 L5 8 L10 13" fill="none" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}
