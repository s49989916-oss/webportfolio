import { useEffect, useRef, useState } from "react";

type TechTextProps = {
  text: string;
  fontWeight?: number;
  fontSize?: number;
  reveal?: "letter" | "word";
  dashLength?: number;
  dashGap?: number;
  specks?: number;
  intro?: "none" | "rise";
  introDuration?: number;
  clickKick?: boolean;
  guides?: boolean;
};

const SVG_NS = "http://www.w3.org/2000/svg";

export default function TechText({
  text,
  fontWeight = 500,
  fontSize = 120,
  reveal = "letter",
  dashLength = 4,
  dashGap = 2,
  specks = 12,
  intro = "none",
  introDuration = 2,
  clickKick = false,
  guides = false,
}: TechTextProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const kick = useRef(0);
  const [drawn, setDrawn] = useState(false);

  useEffect(() => {
    const svg = svgRef.current;
    const wrap = wrapRef.current;
    if (!svg || !wrap) return;

    const measurer = document.createElement("canvas").getContext("2d");
    if (!measurer) return;

    let frame = 0;
    let running = true;
    let announced = false;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const started = performance.now();
    const speckle = Array.from({ length: specks }, (_, i) => ({
      u: ((i * 97) % 100) / 100,
      v: ((i * 53) % 100) / 100,
      s: 0.8 + ((i * 17) % 8) / 8,
      p: (i * 0.7) % (Math.PI * 2),
    }));

    const guideA = document.createElementNS(SVG_NS, "line");
    const guideB = document.createElementNS(SVG_NS, "line");
    const group = document.createElementNS(SVG_NS, "g");
    const letters = (reveal === "word" ? [text] : [...text]).map(() => {
      const node = document.createElementNS(SVG_NS, "text");
      node.setAttribute("fill", "#f6f1ea");
      node.setAttribute("stroke", "rgba(246,241,234,0.9)");
      node.setAttribute("stroke-linejoin", "round");
      node.setAttribute("font-family", "Outfit, sans-serif");
      node.setAttribute("dominant-baseline", "middle");
      group.append(node);
      return node;
    });
    const dots = speckle.map(() => {
      const node = document.createElementNS(SVG_NS, "rect");
      group.append(node);
      return node;
    });
    if (guides) {
      guideA.setAttribute("stroke", "rgba(198,163,106,0.5)");
      guideB.setAttribute("stroke", "rgba(198,163,106,0.5)");
      guideA.setAttribute("stroke-dasharray", `${dashLength} ${dashGap}`);
      guideB.setAttribute("stroke-dasharray", `${dashLength} ${dashGap}`);
      svg.append(guideA, guideB);
    }
    svg.append(group);

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      svg.setAttribute("viewBox", `0 0 ${Math.max(1, rect.width)} ${Math.max(1, rect.height)}`);
    };
    resize();

    const paint = (now: number) => {
      if (!running) return;
      const rect = wrap.getBoundingClientRect();
      const w = rect.width;
      const h = rect.height;
      const elapsed = Math.max(0, (now - started - kick.current) / 1000);
      const span = Math.max(0.4, introDuration);
      const global = reduce ? 1 : Math.min(1, elapsed / span);
      const rise = intro === "rise" && !reduce ? (1 - Math.min(1, elapsed / (span * 0.55))) * 26 : 0;
      const fitted = Math.min(fontSize, Math.max(48, w / (text.length * 0.72)));
      const parts = reveal === "word" ? [text] : [...text];

      measurer.font = `${fontWeight} ${fitted}px Outfit, sans-serif`;
      const widths = parts.map((ch) => measurer.measureText(ch).width);
      const tracking = fitted * 0.08;
      const total = widths.reduce((sum, width) => sum + width, 0) + tracking * Math.max(0, parts.length - 1);
      let x = (w - total) / 2;
      const y = h * 0.56 + rise;

      if (guides) {
        guideA.setAttribute("x1", String(x - 16));
        guideA.setAttribute("x2", String(x + total + 16));
        guideA.setAttribute("y1", String(y));
        guideA.setAttribute("y2", String(y));
        guideB.setAttribute("x1", String(x - 16));
        guideB.setAttribute("x2", String(x + total + 16));
        guideB.setAttribute("y1", String(y - fitted * 0.36));
        guideB.setAttribute("y2", String(y - fitted * 0.36));
      }

      parts.forEach((ch, i) => {
        const node = letters[i];
        if (!node) return;
        const stagger = reveal === "word" ? 0 : i * (span * 0.07);
        const local = reduce ? 1 : clamp((elapsed - stagger) / (span * 0.45));
        node.textContent = ch;
        node.setAttribute("x", String(x));
        node.setAttribute("y", String(y));
        node.setAttribute("font-size", String(fitted));
        node.setAttribute("font-weight", String(fontWeight));
        node.setAttribute("stroke-width", String(Math.max(1, fitted * 0.02)));
        node.setAttribute("stroke-dasharray", `${dashLength} ${dashGap}`);
        node.setAttribute("stroke-dashoffset", String((1 - local) * 56));
        node.setAttribute("fill-opacity", String(local));
        node.setAttribute("stroke-opacity", String(0.25 + local * 0.75));
        x += (widths[i] ?? 0) + tracking;
      });

      const left = (w - total) / 2;
      dots.forEach((dot, i) => {
        const speck = speckle[i];
        if (!speck) return;
        const appear = reduce ? 1 : clamp((global - 0.2) * 1.5);
        const px = left + speck.u * total;
        const py = y - fitted * 0.62 + speck.v * fitted * 1.2 + Math.sin(elapsed * 1.5 + speck.p) * 3;
        dot.setAttribute("x", String(px));
        dot.setAttribute("y", String(py));
        dot.setAttribute("width", String(speck.s + 0.7));
        dot.setAttribute("height", String(speck.s + 0.7));
        dot.setAttribute("fill", i % 4 === 0 ? "#c6a36a" : "#f6f1ea");
        dot.setAttribute("opacity", String(appear * (0.3 + 0.7 * (0.5 + 0.5 * Math.sin(elapsed * 2.2 + i)))));
      });

      if (!announced && w > 0) {
        announced = true;
        setDrawn(true);
      }
      if (!reduce) frame = requestAnimationFrame(paint);
    };

    const start = () => {
      if (running) frame = requestAnimationFrame(paint);
    };
    void document.fonts.load(`${fontWeight} 96px Outfit`).then(start);
    start();

    const onResize = () => resize();
    window.addEventListener("resize", onResize);
    const observer = new ResizeObserver(() => resize());
    observer.observe(wrap);

    const onKick = () => {
      if (!clickKick) return;
      kick.current = performance.now() - started;
    };
    if (clickKick) wrap.addEventListener("click", onKick);

    return () => {
      running = false;
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", onResize);
      observer.disconnect();
      wrap.removeEventListener("click", onKick);
      guideA.remove();
      guideB.remove();
      group.remove();
    };
  }, [text, fontWeight, fontSize, reveal, dashLength, dashGap, specks, intro, introDuration, clickKick, guides]);

  return (
    <div ref={wrapRef} className={clickKick ? "relative h-full w-full cursor-pointer" : "relative h-full w-full"}>
      <span
        className={
          drawn
            ? "sr-only"
            : "pointer-events-none absolute inset-0 flex items-center justify-center font-sans text-7xl font-medium tracking-widest text-fg sm:text-8xl md:text-9xl"
        }
      >
        {text}
      </span>
      <svg ref={svgRef} aria-hidden className="relative h-full w-full overflow-visible" />
    </div>
  );
}

function clamp(value: number) {
  return Math.max(0, Math.min(1, value));
}
