import { useEffect, useState } from "react";
import { AudioLines, Box, LifeBuoy, MonitorPlay, Sun, Users } from "lucide-react";
import FlexCarousel from "./FlexCarousel";
import FluxLines from "./FluxLines";
import TechText from "./TechText";
import { crew, events, rider, services } from "./data";

const LINE_COLORS = ["#ffffff", "#ffffff", "#f6f1ea"];

const serviceIcons = [AudioLines, Sun, Box, MonitorPlay, LifeBuoy, Users] as const;

const chapters = [
  { id: "vision", label: "Vision" },
  { id: "expertise", label: "Expertise" },
  { id: "events", label: "Events" },
  { id: "inventory", label: "Rider" },
  { id: "contact", label: "Contact" },
] as const;

const facts = [
  { k: "Outdoor", v: "LED P3" },
  { k: "Indoor", v: "LED P2" },
  { k: "Picture", v: "Fine pitch" },
  { k: "Output", v: "High brightness" },
] as const;

export function SameoPortfolio() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("vision");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const nodes = chapters
      .map((chapter) => document.getElementById(chapter.id))
      .filter((node): node is HTMLElement => Boolean(node));
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { threshold: [0.25, 0.45], rootMargin: "-18% 0px -40% 0px" },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    let frame = 0;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        setProgress(max > 0 ? window.scrollY / max : 0);
        frame = 0;
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="relative min-h-screen bg-bg text-fg">
      <FluxLines
        colors={LINE_COLORS}
        glow={2}
        rimWidth={0.2}
        lineWidth={1}
        flowDirection="down"
        mouseInteraction
        clickSwirl
      />
      <div className="vignette" />

      <header className="fixed inset-x-0 top-0 z-40">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 md:px-6 md:py-4">
          <a href="#vision" className="glass rounded-full px-4 py-2 font-display text-lg tracking-[0.22em]">
            SAMEO
          </a>
          <nav className="glass hidden items-center rounded-full p-1 md:flex" aria-label="Primary">
            {chapters.map((chapter) => (
              <a
                key={chapter.id}
                href={`#${chapter.id}`}
                className={
                  active === chapter.id
                    ? "rounded-full bg-fg px-4 py-2 text-xs tracking-[0.16em] text-ink uppercase"
                    : "rounded-full px-4 py-2 text-xs tracking-[0.16em] text-muted uppercase"
                }
              >
                {chapter.label}
              </a>
            ))}
          </nav>
          <a
            href="#contact"
            className="hidden h-11 items-center rounded-full bg-fg px-5 text-xs font-medium tracking-[0.16em] text-ink uppercase md:inline-flex"
          >
            Contact
          </a>
          <button
            type="button"
            className="glass grid h-11 w-11 place-items-center rounded-full md:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            <span className="flex w-4 flex-col gap-1.5">
              <span className={open ? "h-px w-4 bg-fg translate-y-[3.5px] rotate-45" : "h-px w-4 bg-fg"} />
              <span className={open ? "h-px w-4 bg-fg -translate-y-[3.5px] -rotate-45" : "h-px w-4 bg-fg"} />
            </span>
          </button>
        </div>
        <div className="h-px bg-white/10">
          <div className="h-px origin-left bg-gold" style={{ transform: `scaleX(${progress})` }} />
        </div>
      </header>

      {open ? (
        <div className="nav-sheet fixed inset-0 z-30 flex flex-col justify-end bg-bg/70 px-4 pt-24 backdrop-blur-2xl md:hidden">
          <nav className="glass-strong rounded-[1.75rem] p-3" aria-label="Mobile">
            {chapters.map((chapter) => (
              <a
                key={chapter.id}
                href={`#${chapter.id}`}
                onClick={() => setOpen(false)}
                className="flex h-14 items-center justify-between border-b border-line px-4 text-lg last:border-b-0"
              >
                <span>{chapter.label}</span>
                <span className="text-xs tracking-[0.18em] text-gold uppercase">0{chapters.indexOf(chapter) + 1}</span>
              </a>
            ))}
          </nav>
        </div>
      ) : null}

      <nav className="fixed top-1/2 right-3 z-30 hidden -translate-y-1/2 flex-col lg:flex" aria-label="Chapters">
        {chapters.map((chapter) => (
          <a key={chapter.id} href={`#${chapter.id}`} className="grid h-11 w-11 place-items-center" aria-label={chapter.label}>
            <span className={active === chapter.id ? "h-7 w-px bg-gold" : "h-4 w-px bg-white/30"} />
          </a>
        ))}
      </nav>

      <main className="relative z-10">
        <section id="vision" className="flex min-h-svh flex-col justify-center px-5 pt-24 pb-16">
          <div className="mx-auto flex w-full max-w-5xl flex-col items-center text-center">
            <p className="rise-in text-xs tracking-[0.42em] text-gold uppercase">AV & Events Solutions</p>
            <div className="mark-stage mt-4 w-full">
              <h1 className="h-full">
                <TechText
                  text="SAMEO"
                  fontWeight={600}
                  fontSize={150}
                  reveal="letter"
                  dashLength={4}
                  dashGap={2}
                  specks={15}
                  intro="none"
                  introDuration={2}
                  clickKick
                  guides={false}
                />
              </h1>
            </div>
            <p className="rise-in font-display text-3xl text-fg sm:text-5xl">Your vision. Our expertise.</p>
            <p className="rise-in mt-5 max-w-xl text-base text-muted sm:text-lg">
              Professional AV solutions for events of every size — from corporate functions to concerts, exhibitions and more.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
              {["Sound", "Lighting", "Truss", "LED", "Stage", "Crew"].map((item) => (
                <span key={item} className="glass rounded-full px-4 py-2 text-xs tracking-[0.18em] text-fg uppercase">
                  {item}
                </span>
              ))}
            </div>
          </div>
        </section>

        <section id="expertise" className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
          <SectionHead index="01" kicker="What we bring" title="The floor, fully dressed." />
          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service, index) => {
              const Icon = serviceIcons[index] ?? AudioLines;
              return (
                <article key={service.title} className="glass rounded-[1.75rem] p-6">
                  <div className="flex items-center justify-between">
                    <span className="grid h-11 w-11 place-items-center rounded-full border border-line text-gold">
                      <Icon size={18} strokeWidth={1.5} />
                    </span>
                    <span className="font-display text-2xl text-gold/80">{service.index}</span>
                  </div>
                  <h3 className="mt-8 font-display text-3xl leading-none">{service.title}</h3>
                  <p className="mt-4 text-sm leading-6 text-muted">{service.copy}</p>
                </article>
              );
            })}
          </div>
          <dl className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {facts.map((fact) => (
              <div key={fact.v} className="glass rounded-[1.75rem] px-5 py-4">
                <dt className="text-xs tracking-[0.2em] text-muted uppercase">{fact.k}</dt>
                <dd className="mt-2 font-display text-2xl">{fact.v}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section id="events" className="mx-auto max-w-6xl px-5 py-12 md:px-6 md:py-20">
          <SectionHead index="02" kicker="Where it plays" title="Every room. Same standard." />
          <div className="event-stage mt-8">
            <FlexCarousel
              items={events}
              preset="liquid"
              intro="rise"
              cardHeight={0.72}
              gap={12}
              squeeze={0.2}
              focusOnClick
              captions
            />
          </div>
        </section>

        <section id="inventory" className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
          <SectionHead index="03" kicker="House rider" title="What is actually on the truck." />
          <p className="mt-4 max-w-xl text-muted">
            Quantities from the working inventory — sound, light, truss, stage, LED and the people who run them.
          </p>
          <div className="mt-10 grid gap-4 lg:grid-cols-2">
            {rider.map((group) => (
              <article key={group.id} id={group.id} className="glass rounded-[1.75rem] p-6 md:p-8">
                <p className="text-xs tracking-[0.22em] text-gold uppercase">{group.index}</p>
                <h3 className="mt-2 font-display text-4xl">{group.title}</h3>
                <p className="mt-2 text-sm text-muted">{group.lede}</p>
                <ul className="mt-6">
                  {group.rows.map((row) => (
                    <li
                      key={`${group.id}-${row.name}`}
                      className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-4 border-t border-line py-3"
                    >
                      <span className="min-w-0">
                        <span className="block text-fg">{row.name}</span>
                        <span className="text-sm text-muted">{row.spec}</span>
                      </span>
                      <span className="text-sm tracking-wide text-gold">{row.qty}</span>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
            <article className="glass-strong rounded-[1.75rem] p-6 md:p-8">
              <p className="text-xs tracking-[0.22em] text-gold uppercase">07</p>
              <h3 className="mt-2 font-display text-4xl">Event Crew</h3>
              <p className="mt-2 text-sm text-muted">The call sheet that shows up with the gear.</p>
              <ul className="mt-6">
                {crew.map((role) => (
                  <li key={role} className="flex items-center justify-between border-t border-line py-4">
                    <span>{role}</span>
                    <span className="text-xs tracking-[0.18em] text-gold uppercase">On site</span>
                  </li>
                ))}
              </ul>
            </article>
          </div>
        </section>

        <section id="contact" className="mx-auto max-w-6xl px-5 py-20 md:px-6 md:py-28">
          <p className="text-xs tracking-[0.28em] text-gold uppercase">Contact</p>
          <h2 className="mt-4 max-w-3xl font-display text-5xl leading-none sm:text-7xl">
            Let's make your event unforgettable.
          </h2>
          <div className="mt-10 grid gap-3 md:grid-cols-2">
            <a href="tel:0563104314" className="glass rounded-[1.75rem] p-6 transition-transform duration-200 hover:-translate-y-0.5 md:p-8">
              <span className="text-xs tracking-[0.22em] text-muted uppercase">Call</span>
              <span className="mt-3 block font-display text-4xl sm:text-5xl">056 310 4314</span>
            </a>
            <a
              href="mailto:muhammadsami2026@gmail.com"
              className="glass rounded-[1.75rem] p-6 transition-transform duration-200 hover:-translate-y-0.5 md:p-8"
            >
              <span className="text-xs tracking-[0.22em] text-muted uppercase">Email</span>
              <span className="mt-3 block font-display text-3xl break-all sm:text-4xl">muhammadsami2026@gmail.com</span>
            </a>
          </div>
        </section>
      </main>

      <footer className="relative z-10 mx-auto flex max-w-6xl flex-col gap-2 px-5 py-10 text-sm text-muted md:flex-row md:items-center md:justify-between md:px-6">
        <p className="tracking-[0.22em] text-fg uppercase">SAMEO</p>
        <p>AV & Events Solutions</p>
      </footer>
    </div>
  );
}

function SectionHead({ index, kicker, title }: { index: string; kicker: string; title: string }) {
  return (
    <div className="max-w-3xl">
      <p className="text-xs tracking-[0.28em] text-gold uppercase">
        {index} — {kicker}
      </p>
      <h2 className="mt-3 font-display text-5xl leading-none sm:text-6xl">{title}</h2>
    </div>
  );
}
