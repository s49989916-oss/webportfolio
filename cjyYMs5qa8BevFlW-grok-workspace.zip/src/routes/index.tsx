import { createFileRoute } from "@tanstack/react-router";
import { SameoPortfolio } from "@/components/sameo/SameoPortfolio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SameoPortfolio />;
}
